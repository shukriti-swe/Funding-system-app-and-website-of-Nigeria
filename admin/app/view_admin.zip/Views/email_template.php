<?= $this->extend('master') ?>
<?= $this->section('content') ?> 
hello
<?= $this->endSection() ?>